package com.oceanit.hoseo_oceanit;

import java.util.Locale;

public class Tools {

    Locale locale = Locale.getDefault();
    String language =locale.getLanguage(); //언어 추출
    Boolean loginok = false;
    String admin = "null";
    String username = "";
    String myid = "admin";
    String pass = "hoseo";
    String saveid = "";
    Boolean checkbox = false;
    String URL = "http://210.119.107.82";

}
