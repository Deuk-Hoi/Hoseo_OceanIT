package com.oceanit.hoseo_oceanit;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import static android.util.Log.e;

public class RecyclerAdapter_member extends RecyclerView.Adapter<RecyclerAdapter_member.ViewHolder> {

    Context context;
    List<Item_member> items;
    int item_layout;
    Tools tools = new Tools();
    String language = tools.language;

    public RecyclerAdapter_member(Context context, List<Item_member> items, int item_layout)
    {
        this.context = context;
        this.items = items;
        this.item_layout = item_layout;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_member,null);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        final Item_member item = items.get(i);
        Drawable drawable = ContextCompat.getDrawable(context, item.getMember_image());
        viewHolder.member_image.setBackground(drawable);
        viewHolder.name.setText(item.getName());
        viewHolder.position.setText(item.getPosition());
        viewHolder.email.setText(item.getEmail());
        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String log = item.getName();
                e("log",log);
                Intent intent = null;
                switch (item.getName()) {
                    case "조용갑":
                    case "Yong Gap Cho":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/choyongkap");
                            intent.putExtra("name", "조용갑");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-5178");
                            intent.putExtra("email", "ykcho@hoseo.edu");
                            intent.putExtra("bachelor_school", "명지대학교");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "중앙대학교");
                            intent.putExtra("master_major", "물류정보");
                            intent.putExtra("master_degree", "경영학석사");
                            intent.putExtra("doctor_school", "한국해양대학교");
                            intent.putExtra("doctor_major", "해운및상해보험");
                            intent.putExtra("doctor_degree", "경영학박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/choyongkap");
                            intent.putExtra("name", "Yong Gap Cho");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-5178");
                            intent.putExtra("email", "ykcho@hoseo.edu");
                            intent.putExtra("bachelor_school", "Myongji Univ.");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "Chung-Ang Univ.");
                            intent.putExtra("master_major", "Logistics Information");
                            intent.putExtra("master_degree", "Master of Business Administration");
                            intent.putExtra("doctor_school", "Korea Maritime Univ.");
                            intent.putExtra("doctor_major", "Shipping and accident insurance");
                            intent.putExtra("doctor_degree", "Doctor of Business Administration");
                        }
                        context.startActivity(intent);
                        break;

                    case "고학림":
                    case "Hak Rim GO":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/gohaklim");
                            intent.putExtra("name", "고학림");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-5691");
                            intent.putExtra("email", "hlko@hoseo.edu");
                            intent.putExtra("bachelor_school", "숭실대학교");
                            intent.putExtra("bachelor_major", "전자공학");
                            intent.putExtra("bachelor_degree", "공학사");
                            intent.putExtra("master_school", "Fairlgh Dickinson Univ.");
                            intent.putExtra("master_major", "전자공학");
                            intent.putExtra("master_degree", "공학석사");
                            intent.putExtra("doctor_school", "North Carolina State Univ.");
                            intent.putExtra("doctor_major", "전기,컴퓨터공학");
                            intent.putExtra("doctor_degree", "공학박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/gohaklim");
                            intent.putExtra("name", "Hak Rim GO");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-5691");
                            intent.putExtra("email", "hlko@hoseo.edu");
                            intent.putExtra("bachelor_school", "Soongsil Univ.");
                            intent.putExtra("bachelor_major", "Electronic Engineering");
                            intent.putExtra("bachelor_degree", "Bachelor of Engineer");
                            intent.putExtra("master_school", "Fairlgh Dickinson Univ.");
                            intent.putExtra("master_major", "Electronic Engineering");
                            intent.putExtra("master_degree", "Master of Engineering");
                            intent.putExtra("doctor_school", "North Carolina State Univ.");
                            intent.putExtra("doctor_major", "Electrical and Computer Engineering");
                            intent.putExtra("doctor_degree", "Doctor of Engineering");
                        }
                        context.startActivity(intent);
                        break;

                    case "임태호":
                    case "Tae Ho Im":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/limteaho");
                            intent.putExtra("name", "임태호");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9640");
                            intent.putExtra("email", "taehoim@hoseo.edu");
                            intent.putExtra("bachelor_school", "");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "중앙대학교");
                            intent.putExtra("doctor_major", "정보통신");
                            intent.putExtra("doctor_degree", "박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/limteaho");
                            intent.putExtra("name", "Tae Ho Im");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9640");
                            intent.putExtra("email", "taehoim@hoseo.edu");
                            intent.putExtra("bachelor_school", "");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "Chung-ang Univ.");
                            intent.putExtra("doctor_major", "Information and communication");
                            intent.putExtra("doctor_degree", "Doctor");
                        }
                        context.startActivity(intent);
                        break;

                    case "조용호":
                    case "Yong Ho Cho"://이메일 수정해야함.
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/choyongho");
                            intent.putExtra("name", "조용호");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-5947");
                            intent.putExtra("email", "ykcho@hoseo.edu");
                            intent.putExtra("bachelor_school", "");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "한국과학기술원");
                            intent.putExtra("doctor_major", "전기및전자공학");
                            intent.putExtra("doctor_degree", "박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/choyongho");
                            intent.putExtra("name", "Yong Ho Cho");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-5947");
                            intent.putExtra("email", "ykcho@hoseo.edu");
                            intent.putExtra("bachelor_school", "");
                            intent.putExtra("bachelor_major", "");
                            intent.putExtra("bachelor_degree", "");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "KAIST");
                            intent.putExtra("doctor_major", "Electrical and electronic engineering");
                            intent.putExtra("doctor_degree", "Doctor");
                        }
                        context.startActivity(intent);
                        break;

                    case "김계원":
                    case "Gye Won Kim":
                        Log.e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/kimgyewon");
                            intent.putExtra("name", "김계원");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9831");
                            intent.putExtra("email", "kwkim@hoseo.edu");
                            intent.putExtra("bachelor_school", "호서대학교");
                            intent.putExtra("bachelor_major", "정보통신공학");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "호서대학교");
                            intent.putExtra("master_major", "정보통신공학");
                            intent.putExtra("master_degree", "석사");
                            intent.putExtra("doctor_school", "호서대학교");
                            intent.putExtra("doctor_major", "정보통신공학");
                            intent.putExtra("doctor_degree", "박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/kimgyewon");
                            intent.putExtra("name", "Gye Won Kim");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9831");
                            intent.putExtra("email", "kwkim@hoseo.edu");
                            intent.putExtra("bachelor_school", "Hoseo Univ.");
                            intent.putExtra("bachelor_major", "Information and communication engineering");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "Hoseo Univ.");
                            intent.putExtra("master_major", "Information and communication engineering");
                            intent.putExtra("master_degree", "Master");
                            intent.putExtra("doctor_school", "Hoseo Univ.");
                            intent.putExtra("doctor_major", "Information and communication engineering");
                            intent.putExtra("doctor_degree", "Doctor");
                        }
                        context.startActivity(intent);
                        break;

                    case "김민상":
                    case "Min Sang Kim":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/kimminsang");
                            intent.putExtra("name", "김민상");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "misang@hoseo.edu");
                            intent.putExtra("bachelor_school", "호서대학교");
                            intent.putExtra("bachelor_major", "정보통신공학");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "호서대학교");
                            intent.putExtra("master_major", "정보통신공학");
                            intent.putExtra("master_degree", "석사");
                            intent.putExtra("doctor_school", "호서대학교");
                            intent.putExtra("doctor_major", "정보통신공학");
                            intent.putExtra("doctor_degree", "박사");
                        } else {
                            intent.putExtra("member_image2", "@drawable/kimminsang");
                            intent.putExtra("name", "Min Sang Kim");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "misang@hoseo.edu");
                            intent.putExtra("bachelor_school", "Hoseo Univ.");
                            intent.putExtra("bachelor_major", "Information and communication engineering");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "Hoseo Univ.");
                            intent.putExtra("master_major", "Information and communication engineering");
                            intent.putExtra("master_degree", "Master");
                            intent.putExtra("doctor_school", "Hoseo Univ.");
                            intent.putExtra("doctor_major", "Information and communication engineering");
                            intent.putExtra("doctor_degree", "Doctor");
                        }
                        context.startActivity(intent);
                        break;

                    case "차민혁":
                    case "Min Hyeok Cha":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/chaminhyeok");
                            intent.putExtra("name", "차민혁");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "dwmh86@hoseo.edu");
                            intent.putExtra("bachelor_school", "호서대학교");
                            intent.putExtra("bachelor_major", "정보통신공학");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "호서대학교");
                            intent.putExtra("master_major", "정보통신공학");
                            intent.putExtra("master_degree", "석사");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        } else {
                            intent.putExtra("member_image2", "@drawable/chaminhyeok");
                            intent.putExtra("name", "Min Hyeok Cha");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "dwmh86@hoseo.edu");
                            intent.putExtra("bachelor_school", "Hoseo Univ.");
                            intent.putExtra("bachelor_major", "Information and communication engineering");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "Hoseo Univ.");
                            intent.putExtra("master_major", "Information and communication engineering");
                            intent.putExtra("master_degree", "Master");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        }
                        context.startActivity(intent);
                        break;

                    case "김길용":
                    case "Gil Yong Kim":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/kimgillyong");
                            intent.putExtra("name", "김길용");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "kykim@hoseo.edu");
                            intent.putExtra("bachelor_school", "호서대학교");
                            intent.putExtra("bachelor_major", "정보통신공학");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        } else {
                            intent.putExtra("member_image2", "@drawable/kimgillyong");
                            intent.putExtra("name", "Gil Yong Kim");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "kykim@hoseo.edu");
                            intent.putExtra("bachelor_school", "Hoseo Univ.");
                            intent.putExtra("bachelor_major", "Information and communication engineering");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        }
                        context.startActivity(intent);
                        break;

                    case "김세연":
                    case "Se Yeon Kim":
                        e("log", "error_in");
                        intent = new Intent(context, Member_info.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (language.equals("ko")) {
                            intent.putExtra("member_image2", "@drawable/kimsaeyun");
                            intent.putExtra("name", "김세연");
                            intent.putExtra("position", "해양IT융합기술연구소");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "seyeon92@hoseo.edu");
                            intent.putExtra("bachelor_school", "호서대학교");
                            intent.putExtra("bachelor_major", "정보통신공학");
                            intent.putExtra("bachelor_degree", "학사");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        } else {
                            intent.putExtra("member_image2", "@drawable/kimsaeyun");
                            intent.putExtra("name", "Se Yeon Kim");
                            intent.putExtra("position", "Ocean IT");
                            intent.putExtra("call", "041-540-9565");
                            intent.putExtra("email", "seyeon92@hoseo.edu");
                            intent.putExtra("bachelor_school", "Hoseo Univ.");
                            intent.putExtra("bachelor_major", "Information and communication engineering");
                            intent.putExtra("bachelor_degree", "Bachelor");
                            intent.putExtra("master_school", "");
                            intent.putExtra("master_major", "");
                            intent.putExtra("master_degree", "");
                            intent.putExtra("doctor_school", "");
                            intent.putExtra("doctor_major", "");
                            intent.putExtra("doctor_degree", "");
                        }
                        context.startActivity(intent);
                        break;
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView member_image;
        TextView name;
        TextView position;
        TextView email;
        CardView cardView;

        public ViewHolder(View itemView)
        {
            super(itemView);
            member_image = (ImageView) itemView.findViewById(R.id.member_image);
            name = (TextView) itemView.findViewById(R.id.researcher_name);
            position = (TextView) itemView.findViewById(R.id.researcher_position);
            email = (TextView) itemView.findViewById(R.id.researcher_email);
            cardView = (CardView)itemView.findViewById(R.id.member_card);
        }
    }
}
